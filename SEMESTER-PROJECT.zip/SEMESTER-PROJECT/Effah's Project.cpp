#include <iostream>
#include <unordered_map>
#include <string>

using namespace std;

		string;

void addPassword(const string& website, const string& password) {
    passwordMap[website] = password;
}

void getPassword(const string& website) {
    if (passwordMap.count(website) > 0) {
        cout << "Password for " << website << ": " << passwordMap[website] << endl;
    } else {
        cout << "No password found for " << website << endl;
    }
}

void removePassword(const string& website) {
    if (passwordMap.count(website) > 0) {
        passwordMap.erase(website);
        cout << "Password removed for " << website << endl;
    } else {
        cout << "No password found for " << website << endl;
    }
}

int main() {
    int choice;
    string website, password;

    while (true) {
        cout << "Password Manager Menu" << endl;
        cout << "1. Add Password" << endl;
        cout << "2. Get Password" << endl;
        cout << "3. Remove Password" << endl;
        cout << "4. Exit" << endl;
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                cout << "Enter website: ";
                cin >> website;
                cout << "Enter password: ";
                cin >> password;
                addPassword(website, password);
                cout << "Password added successfully!" << endl;
                break;
            case 2:
                cout << "Enter website: ";
                cin >> website;
                getPassword(website);
                break;
            case 3:
                cout << "Enter website: ";
                cin >> website;
                removePassword(website);
                break;
            case 4:
                cout << "Exiting..." << endl;
                return 0;
            default:
                cout << "Invalid choice. Please try again." << endl;
        }

        cout << endl;
    }

    return 0;
}



